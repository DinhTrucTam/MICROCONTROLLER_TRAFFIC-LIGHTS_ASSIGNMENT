/*
 * global.c
 *
 *  Created on: Jan 5, 2023
 *      Author: nguye
 */


